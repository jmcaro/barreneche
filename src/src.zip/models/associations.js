import UserConsultation from "./UsuariosConsulta.js";
import Rol from "./Roles.js";
import Categoria from "./Categorias.js";
import Consulta from "./Consultas.js";
import Usuario from "./Usuarios.js";

Usuario.belongsToMany(Consulta, {
  through: UserConsultation,
});
Consulta.belongsToMany(Usuario, {
  through: UserConsultation,
});

Usuario.belongsTo(Rol, {
  as: "roles",
});

Consulta.belongsTo(Categoria, {
  as: "categoria",
});
