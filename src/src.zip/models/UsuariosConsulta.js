import { DataTypes, Model } from "sequelize";
import { sequelize } from "../database/mysql.js";

class UserConsultation extends Model {}
UserConsultation.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
  },
  {
    sequelize,
    tableName: "user_consultation",
    UsuarioId: {
      type: DataTypes.UUID,
      references: {
        model: "Usuario",
        key: "id",
      },
    },
    ConsultumId: {
      type: DataTypes.UUID,
      references: {
        model: "Consulta",
        key: "id",
      },
    },
  }
);

/* await Usuario.sync();
await Consulta.sync();
await UsuariosConsulta.sync();
 */
//await UserConsultation.sync();
export default UserConsultation;
