import express from "express";
import morgan from "morgan";
import cors from "cors";
import exphbs from "express-handlebars";
import { dirname, resolve } from "path";
import { fileURLToPath } from "url";
import methodOverride from "method-override";
import * as helpers from "./assets/js/utilsHBS.js";
import cookieParser from "cookie-parser";
//import UsuariosConsulta from "../src/models/UsuariosConsulta.js";

const app = express();
app.use(cookieParser());
const __dirname = dirname(fileURLToPath(import.meta.url));
import { sequelize } from "../src/database/mysql.js";
import "../src/models/associations.js";

//public files
const assets = resolve(__dirname + "/assets");
app.use(express.static(assets));
//console.log(assets);

// template engine
// config view engine
const hbs = exphbs.create({
  extname: ".hbs",
  runtimeOptions: {
    allowProtoPropertiesByDefault: true,
    allowedProtoMethodsByDefault: true,
  },
  helpers,
});
app.engine(".hbs", hbs.engine);
app.set("view engine", ".hbs");
app.set("views", resolve(__dirname + "/views"));

//Middlewares
app.use(morgan("dev"));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(methodOverride("_method"));

//Routes
import roles from "./routes/roles.routes.js";
app.use(roles);

import categorias from "./routes/categorias.routes.js";
app.use(categorias);

import consulta from "./routes/consultas.routes.js";
app.use(consulta);

import auth from "./routes/auth.routes.js";
app.use(auth);

import usuarios from "./routes/usuarios.routes.js";
app.use(usuarios);

import home from "./routes/home.routes.js";
app.use(home);

export default app;
